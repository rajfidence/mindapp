@extends('layouts.app')
@section('content')

<div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                        <div class="panel-heading">
                        Below are some Questions for you to answer.</div>
                    <div class="panel-body">
                     {!! Form::open(['method' => 'POST', 'route' => ['answers.store']]) !!}
                    @if($questions)
                    <?php $i = 1; ?>
                    @foreach($questions as $question)
                        <div class="card" style="margin: 50px">
                            <div class="card-header">
                            {{$question->question_name}}
                            </div>
                            <input
                            type="hidden"
                            name="questions[{{ $i }}]"
                            value="{{ $question->id }}">
                            <ul class="list-group list-group-flush">
                            @foreach($question->options as $option)
                           
                                    <li class="list-group-item">  <input
                                        type="radio"
                                        name="answers[{{ $question->id }}]"
                                        value="{{ $option->id }}"/>
                                        {{ $option->option_name }}
                                    </li>
                        @endforeach
                            </ul>
                        </div>
                        <?php $i++; ?>
                      @endforeach
                      {!! Form::submit('Submit',['class'=>'btn btn-primary']) !!} 
                      @endif
                      {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection