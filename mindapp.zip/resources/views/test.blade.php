




@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Answers</div>

                <div class="panel-body">
                        @foreach($result as $result)
                        
                        <h4> {{$result->question->question_name}}</h4>
                        <h4> {{$result->option->option_name}}</h4>
                        
                        @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
