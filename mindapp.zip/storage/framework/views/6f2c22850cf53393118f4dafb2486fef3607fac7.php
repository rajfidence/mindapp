<?php $__env->startSection('content'); ?>

<div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                        <div class="panel-heading">
                        Below are some Questions for you to answer.</div>
                    <div class="panel-body">
                     <?php echo Form::open(['method' => 'POST', 'route' => ['answers.store']]); ?>

                    <?php if($questions): ?>
                    <?php $i = 1; ?>
                    <?php foreach($questions as $question): ?>
                        <div class="card" style="margin: 50px">
                            <div class="card-header">
                            <?php echo e($question->question_name); ?>

                            </div>
                            <input
                            type="hidden"
                            name="questions[<?php echo e($i); ?>]"
                            value="<?php echo e($question->id); ?>">
                            <ul class="list-group list-group-flush">
                            <?php foreach($question->options as $option): ?>
                           
                                    <li class="list-group-item">  <input
                                        type="radio"
                                        name="answers[<?php echo e($question->id); ?>]"
                                        value="<?php echo e($option->id); ?>"/>
                                        <?php echo e($option->option_name); ?>

                                    </li>
                        <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php $i++; ?>
                      <?php endforeach; ?>
                      <?php echo Form::submit('Submit',['class'=>'btn btn-primary']); ?> 
                      <?php endif; ?>
                      <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>